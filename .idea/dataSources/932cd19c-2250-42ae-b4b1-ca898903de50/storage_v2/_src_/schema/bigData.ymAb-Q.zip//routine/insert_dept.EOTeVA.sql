CREATE PROCEDURE insert_dept(IN start INT(10), IN max_num INT(10))
  BEGIN
    declare i int default 0;
    set autocommit = 0;
    REPEAT
      set i = i+1;
      insert into dept(deptno, dname, loc) VALUES ((start+i) , rand_string(10),rand_string(8));
    UNTIL i= max_num END REPEAT;
    commit;
  END;

