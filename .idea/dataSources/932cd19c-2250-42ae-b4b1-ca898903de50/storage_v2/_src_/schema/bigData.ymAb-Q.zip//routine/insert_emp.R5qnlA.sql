CREATE PROCEDURE insert_emp(IN start INT(10), IN max_num INT(10))
  BEGIN
  declare i int default 0;
  #set autocommit = 0 把autocimnmit设置成0
  set autocommit = 0;
  REPEAT
    set i=i+1;
    insert into emp(empno, ename, job, mgr, hiredata, sal, comm, deptno) values((start+i)
    ,rand_string(6),'SALESMAN',0001,CURDATE(),2000,400,rand_num());
  UNTIL i= max_num  END REPEAT;
  commit;
END;

