CREATE FUNCTION rand_string(n INT)
  RETURNS VARCHAR(255)
  BEGIN
  declare chars_str varchar(100) default 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  declare return_str varchar(255) default '';
  declare i int default 0;
  while i<n DO
    set return_str = concat(return_str,substring(chars_str,floor(1+rand()*52),1));
    set i = i+1;
  END WHILE;
  return return_str;
END;

