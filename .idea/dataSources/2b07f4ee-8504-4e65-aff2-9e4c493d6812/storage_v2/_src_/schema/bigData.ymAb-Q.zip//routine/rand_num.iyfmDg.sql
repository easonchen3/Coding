CREATE FUNCTION rand_num()
  RETURNS INT(5)
  BEGIN
  declare i int default 0;
  set i = floor(100+rand()*10);
  return i;
END;

